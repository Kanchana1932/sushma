<?php
$con=mysqli_connect("localhost", "root","","image2");
if(mysqli_connect_errno())
{
echo "image".mysqli_connect_error();
}
?>